CREATE TABLE costumers2 (
  id int not null auto_increment,
  fname varchar(255) NOT NULL,
  lname varchar(255) NOT NULL,
  email varchar(255) NOT NULL,
  phone_num varchar(10) NOT NULL,
  interest varchar(255) NOT NULL,
  cpassword varchar(255) not null,
  primary key (id)
);


